`boom.wav` found [here](https://www.freesoundeffects.com/free-track/explosion-5-466450/).

`missile.wav` by Mike Koenig under Attribution 3.0 license, found [here](http://soundbible.com/709-Bottle-Rocket.html).

`pop.wav` by Mark DiAngelo under Attribution 3.0 license, found [here](http://soundbible.com/2067-Blop.html).

`railgun.wav` found [here](https://www.freesoundeffects.com/free-track/bazooka-1-466474/).

`spark.wav` found [here](https://www.freesoundeffects.com/free-track/espark1-426772/).

`sniper.wav` by Kibblesbob in public domain, found [here](http://soundbible.com/1788-Sniper-Rifle.html).

`taunt.wav` by snottyboy under Attribution 3.0 license, found [here](http://soundbible.com/1327-Mortar-Round.html).
